This is Lambda based application for weather api
It has 2  major Folder  weather and terraform

Weather Folder has the Lambda application, and terraform has the infrastructure code.

to build the application go to weather Folder and then type these commands on command prompt.

npm install
npm run build

Architecture of the app

The Architecture of the app is simple
    controllers
    services
    mappers
    validators

request comes to controller, and then the controller calls the respective service, and return the response

To deploy and run the app for dev enviroment

go to terraform/dev Folder ( there are 4 seperate folder for seperate enviroments)
All the resource are named according to enviroment for clear seperation.


and run these commands

terraform init
terraform apply

once terraform apply is completed we will see the the output link.

But for the app to work, we need to manually add the api keyvalue for the weaether api and weather history api

Go to AWS secret manager and add the secret value in 

currentweatherApiKeydev (for dev)
weatherhistroyApiKeydev (for dev)

This is a manual process only to done once per enviroment.

once this is completed then you call the lambda function like this

https://<lambda-link>/dev/weather/London
https://<lambda-link>/dev/weather/history/London

eg
https://64jr72bpad.execute-api.ap-southeast-2.amazonaws.com/dev/weather/London
https://64jr72bpad.execute-api.ap-southeast-2.amazonaws.com/dev/weather/history/London


if there are errors they are logged to cloud watch. kindly check that

I have only tested the current weather api, as that has a free key to testing purposes
The History api key is not free, so could not be tested.











