
import { IWeatherResponse } from '../interfaces/weather-interface';

const getWeatherForCityResponseMapped = (responseData: IWeatherResponse) => {
    // here we can add the logic to do custom mapping
    return responseData;
}

export const getWeatherHistoryForCityResponseMapped = (responseData: any) => {
    // here we can add the logic to do custom mapping
    return responseData;
}


export default getWeatherForCityResponseMapped;