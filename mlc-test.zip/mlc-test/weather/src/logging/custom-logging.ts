import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, PutCommand } from "@aws-sdk/lib-dynamodb";
import {
    DYNAMODB_TABLE_NAME
} from "../constants";

const customLogInfo = (logText: string,logData: any) => {
    console.log(logText, logData);
}

export const customLogError = (logText: string,logData: any) => {
    console.error(logText, logData);
}

export const customLogInfoToDynamoDB = async (requestId: string,itemType: string,logData: any) => {
    const client = new DynamoDBClient({});

    const docClient = DynamoDBDocumentClient.from(client);

    const logItem = {
        weatherId: `${requestId}-${itemType}`,
        itemType,
        req_resp_data: JSON.stringify(logData),
        date_created: new Date().toLocaleString()
    }

    const params = {
        TableName: DYNAMODB_TABLE_NAME,
        Item: logItem
    }

    customLogInfo("dynamoDB Item", logItem);
    try {
        const resp = await docClient.send(new PutCommand(params));
        customLogInfo("dynamoDB resp", resp);
    } catch (error){
        customLogError("dynamoDB issue", error);
    }

}

export default customLogInfo;