import { APIGatewayProxyEvent } from "aws-lambda";
import customLogInfo, { customLogError, customLogInfoToDynamoDB } from "./logging/custom-logging";
import validateRequest from './validations/validate';
import getControllerFunctionToUse from "./helpers/controller-helper";
import { badRequestResponse, serverErrorResponse } from './helpers/helper';
import { REQUEST } from './constants';

export const handler = async (event: APIGatewayProxyEvent) => {
    customLogInfo('Event: ', event);
    await customLogInfoToDynamoDB(event.requestContext.requestId,REQUEST, event);
    try {
        const isRequestValid = validateRequest(event);
        if (!isRequestValid) {
            return badRequestResponse();
        } else {
            return await getControllerFunctionToUse(event);
        }
    } catch(error: any) {
        customLogError("Error in index", error);
        return serverErrorResponse();
    }
};