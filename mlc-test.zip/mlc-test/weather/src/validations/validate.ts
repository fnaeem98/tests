import { APIGatewayProxyEvent } from 'aws-lambda';

const validateRequest = (event: APIGatewayProxyEvent) : boolean => {
    const eventPathSplit = event.path.split("/");
    return /^[A-Za-z]+$/.test(eventPathSplit[eventPathSplit.length-1]);
}
export default validateRequest;
