import {
    SecretsManagerClient,
    GetSecretValueCommand,
} from "@aws-sdk/client-secrets-manager";
import customLogInfo, { customLogError } from "../logging/custom-logging";
const getWeatherApiSecretValue = async (secretKey: string) => {
    let response: any;
    customLogInfo("aws secretKey :", secretKey);
    try {
      const client = new SecretsManagerClient({
        region: process.env["REGION"] || "ap-southeast-2",
      });
  
      response = await client.send(
        new GetSecretValueCommand({
          SecretId: secretKey,
          VersionStage: "AWSCURRENT",
        })
      );
    } catch (error) {
      customLogError("aws secret error", error);
      throw error;
    }
    customLogInfo("aws secretKey Value:", response.SecretString);
    
    return response.SecretString;
}

export const badRequestResponse = () => {
  const response = {
    statusCode: 400,
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify({message: "Bad request"}),
  };
  return response;
}


export const serverErrorResponse = () => {
  const response = {
    statusCode: 500,
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify({message: "Something went wrong"}),
  };
  return response;
}


export default getWeatherApiSecretValue