import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
import { WEATHER_DETAILS_CITY_RESOURCE , WEATHER_DETAILS_CITY_HISTORY_RESOURCE} from "../constants";
import startProcessWeatherCity from "../controllers/weather-by-city-controller";
import startProcessWeatherCityHistory from '../controllers/weather-history-by-city-controller';
import customLogInfo, { customLogError } from "../logging/custom-logging";

const getControllerFunctionToUse = async (event: APIGatewayProxyEvent) => {
    let controllerFunction = undefined;
    if (event.resource === WEATHER_DETAILS_CITY_RESOURCE) {
        controllerFunction = await startProcessWeatherCity(event);

    } else if (event.resource === WEATHER_DETAILS_CITY_HISTORY_RESOURCE) {
        controllerFunction = await startProcessWeatherCityHistory(event);
    }
    return controllerFunction;

}

export default getControllerFunctionToUse;
