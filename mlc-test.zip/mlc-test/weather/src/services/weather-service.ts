import axios, { AxiosResponse, AxiosRequestConfig, RawAxiosRequestHeaders } from 'axios';
import customLogInfo, { customLogError, customLogInfoToDynamoDB } from "../logging/custom-logging";
import getWeatherForCityResponseMapped, {getWeatherHistoryForCityResponseMapped} from "../mappers/weather-response";
import getWeatherApiSecretValue  from "../helpers/helper";
import WEATHER_BASE_URL, 
    { 
        WEATHER_HISTORY_BASE_URL,
        RESPONSE

    } from "../constants";
import { IWeatherResponse } from '../interfaces/weather-interface';

const getWeatherDetailsByCityName = async (cityName: string, requestId: string) => {
    try {
        const weatherApiSecretValue = await getWeatherApiSecretValue(process.env["WEATHER_API_KEY"]);
        customLogInfo("weather api secret value:", weatherApiSecretValue);
        const weatherEndpoint: string = `${WEATHER_BASE_URL}weather?q=${cityName}&appid=${weatherApiSecretValue}`;
        customLogInfo("weather api endpoint:", weatherEndpoint);
        
        const apiResp: AxiosResponse<IWeatherResponse> = await axios.get(weatherEndpoint);
        if (apiResp.status === 200) {
            customLogInfo("weather api success response:", apiResp);
            await customLogInfoToDynamoDB(requestId,RESPONSE,apiResp.data);
            const mappedResponse = getWeatherForCityResponseMapped(apiResp.data);
            customLogInfo("weather mapped response:", mappedResponse);
            return mappedResponse;
        } else {
            customLogError("Api Error", apiResp.statusText);
            customLogInfoToDynamoDB(requestId,RESPONSE,apiResp.statusText);
            throw new Error(apiResp.statusText);
        }
    
    } catch (error: any) {
        customLogError("Service getWeatherDetailsByCityName Error", error);
        throw new Error(error?.message);
    }
    
};

export const getWeatherHistoryByCityName = async (cityName: string,  requestId: string) => {
    try {
        const weatherHistoryApiSecretValue = await getWeatherApiSecretValue(process.env["WEATHER_HISTORY_API_KEY"]);
        customLogInfo("weather history api secret value:", weatherHistoryApiSecretValue);
        const weatherEndpoint: string = `${WEATHER_HISTORY_BASE_URL}weather?q=${cityName}&appid=${weatherHistoryApiSecretValue}`;
        customLogInfo("weather history api endpoint:", weatherEndpoint);

        const apiResp = await axios.get(weatherEndpoint);
        if (apiResp.status === 200) {
            customLogInfo("weather history api success response:", apiResp);
            await customLogInfoToDynamoDB(requestId,RESPONSE,apiResp.data);
            const mappedResponse = getWeatherForCityResponseMapped(apiResp.data);
            customLogInfo("weather history mapped response:", mappedResponse);
            return mappedResponse;
        } else {
            customLogError("Api Error", apiResp.statusText);
            customLogInfoToDynamoDB(requestId,RESPONSE,apiResp.statusText);
            throw new Error(apiResp.statusText);
        }

    /*
        return axios.get(weatherEndpoint)
            .then((apiResp: AxiosResponse) => {
                customLogInfo("weather history api success response:", apiResp);
                customLogInfoToDynamoDB(requestId,RESPONSE,apiResp.data);
                const mappedResponse = getWeatherForCityResponseMapped(apiResp.data);
                customLogInfo("weather history mapped response:", mappedResponse);
                return mappedResponse;
            })
            .catch((error: any) => {
                customLogError("Api Error", error);
                customLogInfoToDynamoDB(requestId,RESPONSE,error);
                throw new Error(error?.message);
            });
    */
    } catch(error: any) {
        customLogError("Service getWeatherHistoryByCityName Error", error);
        throw new Error(error?.message);
    }
    
};


export default getWeatherDetailsByCityName;


