const WEATHER_BASE_URL = "https://api.openweathermap.org/data/2.5/";
export const WEATHER_HISTORY_BASE_URL = "https://api.openweathermap.org/data/2.5/";
export const WEATHER_DETAILS_CITY_RESOURCE = "/weather/{cityName}";
export const WEATHER_DETAILS_CITY_HISTORY_RESOURCE = "/weather/history/{cityName}";
export const DYNAMODB_TABLE_NAME = process.env["WAETHER_LOGS_TABLENAME"];
export const REQUEST = "request";
export const RESPONSE = "response";


export default WEATHER_BASE_URL;