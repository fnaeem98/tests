import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
import { getWeatherHistoryByCityName } from "../services/weather-service";
import customLogInfo, { customLogError } from "../logging/custom-logging";

const startProcessWeatherCityHistory = async (event: APIGatewayProxyEvent) => {
    let response;
    let weatherResponse: any = null;
    let weatherResponseStatusCode: number = 500;
    try{
        weatherResponse = await getWeatherHistoryByCityName(event.pathParameters.cityName,  event.requestContext.requestId);
        weatherResponseStatusCode = 200;
        response = {
            statusCode: weatherResponseStatusCode,
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({weatherResponse}),
        };
        customLogInfo("Success startProcessWeatherHistoryCity resp", response);
    } catch (error: any ) {
        weatherResponseStatusCode = 400;
        weatherResponse = JSON.stringify({message: "Bad request / Invalid City"});
        customLogError("WeatherHistoryByCiyController Error", error);
        response = {
            statusCode: weatherResponseStatusCode,
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({weatherResponse}),
        };
        customLogError("Error startProcessWeatherHistoryCity resp", response);
    }
    return response;
};

export default startProcessWeatherCityHistory;
