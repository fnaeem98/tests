import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
import getWeatherDetailsByCityName ,{ getWeatherHistoryByCityName } from "../services/weather-service";
import customLogInfo, { customLogError } from "../logging/custom-logging";


const startProcessWeatherCity = async (event: APIGatewayProxyEvent) => {
    let response;
    let weatherResponse: any = null;
    let weatherResponseStatusCode: number = 500;
    try{
        weatherResponse = await getWeatherDetailsByCityName(event.pathParameters.cityName, event.requestContext.requestId);
        weatherResponseStatusCode = 200;
        response = {
            statusCode: weatherResponseStatusCode,
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({weatherResponse}),
        };
        customLogInfo("Success startProcessWeatherCity resp", response);
    } catch (error: any ) {
        weatherResponseStatusCode = 400;
        weatherResponse = JSON.stringify({message: "Bad request / Invalid City"});
        customLogError("WeatherByCiyController Error", error);
        response = {
            statusCode: weatherResponseStatusCode,
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({weatherResponse}),
        };
        customLogError("Error startProcessWeatherCity resp", response);
    }
    return response;
};

export default startProcessWeatherCity;

